// Componente vazio para garantir que não há popup de instalação
export default function NoInstallPrompt() {
  return null;
}
